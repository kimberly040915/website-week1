#Student Report programme in Python with **Kimberly**

#ask the student for their name
student_name = input("Please enter your name: \n")

#ask the student for their surname
student_surname = input("Please enter your surname: \n")

#ask student for their age, REMEMBER if input()
#funtions always recieve strings (characters) so always convert it to an integer int()
student_age = int(input("Please enter your age \n"))

#create a average variable to hold the total of the 3 marks and give it a value of 0
average_total =0

#ask the student for their 3 marks
subject_1 = int(input("Please enter mark for subject 1: \n"))
subject_2 = int(input("Please enter mark for subject 2: \n"))
subject_3 = int(input("Please enter mark for subject 3: \n"))

#this is the calculation that adds 3 numbers and divides it by 3
average_total = int(((subject_1 + subject_2 + subject_3) / 3))

#lets print and display the results
print("Student Name is :\n",student_name)
print("Student surname is :\n",student_surname)
print("The total average mark is :\n",average_total)

#Advanced Challange
#after calculating the average show the following:
# average less than 50 is fail!
#average equal to and more than 50 but less 74 is a pass
#average equal and about 75 is a distinction

if average_total < 50:
    print("Sorry,you have failed!")

if average_total >= 50 and average_total < 74:
    print("Welldone,you have passed")

if average_total >= 75:
    print("Congratulations,you have passed with a Distinction!!!")
